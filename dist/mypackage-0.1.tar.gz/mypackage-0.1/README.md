#mypackage
This is built to help coders read

#building this package locally
'python setup.py sdist'
